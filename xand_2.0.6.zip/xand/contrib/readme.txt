# Hello,

we are group of people which are taking no property benefits for our phpBB3 activity.
If you do like our themes and want to help us and motivate to do much better work,
you are able to make a donate with any amount.

If you want to donate our team, please visit:
http://www.stylerbb.net/donation.php

with best regards,
StylerBB.net team

# You can download all translations for xand from this page:
http://stylerbb.net/stuff/xand_lang